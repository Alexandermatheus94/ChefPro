import { Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import ListaReceitas from "./pages/ListaReceitas";
import ReceitaDetalhes from "./pages/ReceitaDetalhes";
import AdminLayout from "./pages/admin/AdminLayout";
import NovaReceita from "./pages/admin/NovaReceita";
import ListaAdmin from "./pages/admin/ListaAdmin";
import { PrivateRoute } from "./routes/PrivateRoute";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/receitas" element={<ListaReceitas />} />
      <Route path="/receita/:id" element={<ReceitaDetalhes />} />
      <Route
        path="/admin"
        element={
          <PrivateRoute>
            <AdminLayout />
          </PrivateRoute>
        }
      >
        <Route path="nova" element={<NovaReceita />} />
        <Route path="lista" element={<ListaAdmin />} />
      </Route>
    </Routes>
  );
}

export default App;